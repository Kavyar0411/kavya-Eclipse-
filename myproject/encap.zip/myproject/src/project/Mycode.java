package project;

public class Mycode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encap E1 = new Encap();
		E1.setSerialNum(101);
		E1.setName("mona");
		E1.setAge(15);
		System.out.println(E1);
		

	}

}
