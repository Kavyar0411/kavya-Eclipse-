package com.mvj.ticketbooking;

public class MainTicket {
	public static void main(String[] args) {
		
		Tickets t1=new Tickets();
		t1.available_tickets();
		t1.available_tickets();
		t1.available_tickets();
		t1.available_tickets();
		t1.available_tickets();
		
	}

}
