package com.mvj.Question_1;

import java.util.Scanner;

public class Student {

	public Student() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Student object is created");
	}

}
